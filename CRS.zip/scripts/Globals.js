﻿var local = false;
var WebServiceURL = "CRSWS.asmx"; //the same as above. only with…
if (!local) {
    WebServiceURL = "http://proj.ruppin.ac.il/cegroup8/prod/CRSWS.asmx";
}
